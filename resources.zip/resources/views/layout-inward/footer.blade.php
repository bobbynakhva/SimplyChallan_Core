<!-- Footer Here -->
<footer class="footer__section bgsection pt-120">
   <div class="container">
      <div class="footer__wrapper">
         <div class="footer__top pb-120">
            <div class="row gy-5 gx-5">
               <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="1s">
                  <div class="footer__widget">
                     <div class="widget__head mb__20">
                        <a href="index-2.html" class="footer__logo">
                           <img src="assets/img/logo/logo.png" alt="logo">
                        </a>
                     </div>
                     <p class="pratext mb__20 fz-18">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry...
                     </p>
                     <ul class="social d-flex gap-3">
                        <li>
                           <a href="javascript:void(0)" class="social__icon">
                              <img src="assets/img/svg/facebook.svg" alt="svg">
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0)" class="social__icon">
                              <img src="assets/img/svg/instagram.svg" alt="svg">
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0)" class="social__icon">
                              <img src="assets/img/svg/twitter.svg" alt="svg">
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0)" class="social__icon">
                              <img src="assets/img/svg/ball.svg" alt="svg">
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="1.5s">
                  <div class="footer__widget">
                     <div class="widget__head mb__20">
                        <h4 class="fz-24 pratext">
                           Quick Links
                        </h4>
                     </div>
                     <div class="widget__link">
                        <a href="index-2.html" class="link fz-18 pratext">
                           Home
                        </a>
                        <a href="about.html" class="link fz-18 pratext">
                           About
                        </a>
                        <a href="index-2.html" class="link fz-18 pratext">
                          Rechage & Bill Payment
                        </a>
                        <a href="booking-landing1.html" class="link fz-18 pratext">
                           Booking
                        </a>
                        <a href="contact.html" class="link fz-18 pratext">
                           Contact
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="1.7s">
                  <div class="footer__widget">
                     <div class="widget__head mb__20">
                        <h4 class="fz-24 pratext">
                           Address
                        </h4>
                     </div>
                     <div class="widget__link">
                        <a href="javascript:void(0)" class="link fz-18 pratext">
                          <span class="d-block">
                           (480) 555-0103
                          </span>
                          <span>
                           (406) 555-0120
                          </span>
                        </a>
                        <a href="javascript:void(0)" class="link fz-18 pratext">
                           <span class="d-block">
                              <span class="__cf_email__" data-cfemail="0662636768686728657374726f7546637e676b766a632865696b">[email&#160;protected]</span>
                           </span>
                           <span>
                              <span class="__cf_email__" data-cfemail="86e2e3e4f4e7a8eee9eaf2c6e3fee7ebf6eae3a8e5e9eb">[email&#160;protected]</span>
                           </span>
                        </a>
                        <a href="javascript:void(0)" class="link fz-18 pratext">
                           285 Great North Road, Grey Lynn, Auckland 1021
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-duration="1.9s">
                  <div class="footer__widget">
                     <div class="widget__head mb__20">
                        <h4 class="fz-24 pratext">
                           Newsletter
                        </h4>
                     </div>
                     <div class="widget__link">
                        <p class="fz-18 pratext mb__30">
                           Subscribe our newsletter to get our latest update & news
                        </p>
                       <form action="javacript:void(0)" class="d-flex justify-content-between">
                           <input type="email" placeholder="Your mail address">
                           <button type="submit" class="cmn__btn">
                             <span>
                                 <i class="material-symbols-outlined">
                                    rocket_launch
                                 </i>
                             </span>
                           </button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="footer__bottom d-flex">
            <p class="fz-18 pratext">
               Copyright &copy;2025 <a href="index-2.html" class="base">Rechargio.</a> All Rights Reserved
            </p>
            <ul class="footer__bottom__link">
               <li>
                  <a href="help-support.html">
                     Support
                  </a>
               </li>
               <li>
                  <a href="help-support.html">
                     Terms of Use
                  </a>
               </li>
               <li>
                  <a href="help.html">
                     Privacy Policy
                  </a>
               </li>
            </ul>
         </div>
      </div>
   </div>
</footer>
<!-- Footer End -->