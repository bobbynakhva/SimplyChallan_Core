public function store(Request $request)
    {
        $validated = $request->validate([
            'challan_item_id'        => 'required|exists:challan_items,id',
            'despatch_date'          => 'nullable|date',
            'quantity_returned'      => 'nullable|numeric|min:0',
            'waste_scrap_returned'   => 'nullable|numeric|min:0',
            'waste_not_recoverable'  => 'nullable|numeric|min:0',
            'return_notes'           => 'nullable|string',
        ]);

        // Default status based on quantity_returned
        $validated['status'] = $validated['quantity_returned'] > 0 ? 'Complete' : 'Pending';

        $totalReturned = ($item->quantity_returned + $item->waste_scrap_returned + $item->waste_not_recoverable);

        // Auto-update status
        if ($totalReturned >= $item->total_qty) {
            $item->status = 'Complete';
        } else {
            $item->status = 'Pending';
        }

        $item->save();
        // Get Challan Item
        $challanItem = ChallanItem::findOrFail($validated['challan_item_id']);

        // Calculate total quantity returned so far (including this one)
        $totalReturnedQuantity = ReturnItem::where('challan_item_id', $challanItem->id)->sum('quantity_returned');
        
        //Log::info('Challan store method called', ['request_data' => $request->all()]);
        Log::info('Challan store method called', [$totalReturnedQuantity]);
        // Check if the return quantity exceeds the available quantity
        $newTotalReturned = $totalReturnedQuantity + $validated['quantity_returned'];
        
        if ($newTotalReturned > $challanItem->total_qty) {
            return redirect()->back()->withErrors(['quantity_returned' => 'Returned quantity exceeds sent quantity.']);
        }


        // Create new return item record
        $returnItem = ReturnItem::create($validated);

        //Log::info('Challan store method called', [$challanItem->total_qty]);
        // Remaining goods and remaining price calculation
        $remainingQty = $challanItem->total_qty - $newTotalReturned; // Remaining quantity after all returns
        $remainingPrice = $remainingQty * $challanItem->price_per_kg;

        // Update return item with remaining qty and price
        $returnItem->remaining_qty = $remainingQty;
        $returnItem->remaining_price = $remainingPrice;
        $returnItem->save();

        // Optional: Update ChallanItem status if all quantity is returned
        if ($remainingQty <= 0) {
            $challanItem->status = 'Fully Returned';
        } else {
            $challanItem->status = 'Received';
        }
        $challanItem->save();

        return redirect()->back()->with('success', 'Return entry added successfully!');
    }
    


public function update(Request $request, $id)
{
    $request->validate([
        'company_id' => 'required|exists:companies,id',
        'challan_number' => 'required|string|max:255',
        'date' => 'required|date',
        'purpose' => 'required|string',
        'vehicle_no' => 'nullable|string|max:255',
        'no_of_packages' => 'nullable|numeric',
        'cgst' => 'required|numeric',
        'sgst' => 'required|numeric',
        'total_tax' => 'required|numeric',
        'grand_total' => 'required|numeric',
        'description' => 'nullable|string',
        'items' => 'required|array|min:1',
        'items.*.item_name' => 'required|string',
        'items.*.hsn_code' => 'nullable|string',
        'items.*.price_per_kg' => 'required|numeric',
        'items.*.total_qty' => 'required|numeric',
        'items.*.total_value' => 'required|numeric',
    ]);

    DB::beginTransaction();

    try {
        // Update main challan record
        $challan = Challan::findOrFail($id);
        $challan->update([
            'company_id' => $request->company_id,
            'challan_number' => $request->challan_number,
            'date' => $request->date,
            'purpose' => $request->purpose,
            'vehicle_no' => $request->vehicle_no,
            'no_of_packages' => $request->no_of_packages,
            'cgst' => $request->cgst,
            'sgst' => $request->sgst,
            'total_tax' => $request->total_tax,
            'grand_total' => $request->grand_total,
            'description' => $request->description,
        ]);

        // Delete existing items and re-insert (you can optimize this if needed)
        $challan->items()->delete();

        foreach ($request->items as $item) {
            $challan->items()->create([
                'item_name' => $item['item_name'],
                'hsn_code' => $item['hsn_code'],
                'price_per_kg' => $item['price_per_kg'],
                'total_qty' => $item['total_qty'],
                'total_value' => $item['total_value'],
            ]);
        }

        DB::commit();

        return redirect()->route('challan.index')->with('success', 'Challan updated successfully.');
    } catch (\Exception $e) {
        DB::rollback();

        return redirect()->back()->withErrors(['error' => 'Failed to update challan.'])->withInput();
    }
}



@extends('layout.app')
@section('title', 'Create Challan')
@section('content')
<style type="text/css">
   @media (max-width: 768px) {
    #mobile_text {
        text-align: center !important;
    }
}
</style>
<div class="common__section">
<div class="container-fluid">
<div class="divided__common__body">
<div class="side__sticky">
   <ul class="common__sidebar__wrapper">
   <li class="common__sideitems">
      <a href="{{ route('dashboard') }}" >
      Manage challan
      </a>
   </li>
   <li class="common__sideitems" >
      <a href="{{ route('challan.create') }}" class="active">
      New challan
      </a>
   </li>
   <li class="common__sideitems">
      <a href="{{ route('challan.inward') }}">
      Inward challan
      </a>
   </li>
   <li class="common__sideitems">
      <a href="{{ route('challan.reports') }}">
      Reports
      </a>
   </li>
   </ul>
</div>
<div class="common__body">
   <h2 class="cmn__title" id="mobile_text">
      Create Challan
   </h2>
   <!--home one-->
   <div class="common__body__section pb__60">
      <div class="common__body__head pb__20">
         <!-- <h4>
            Challan
         </h4> -->
         <section class="contact__section pt-30 pb-120">
            <div class="container">
               <div class="row justify-content-center wow fadeInDown">
                  <div class="col-lg-6">
                     <div class="section__header section__center pb__60">
                        <!--<h4 class="text-center" id="mobile_text">
                           Create Challan
                        </h4>
                         <p>
                           Fill up the form and our team will get back to you within 24 hours
                        </p> -->
                     </div>
                  </div>
               </div>
               <div class="row justify-content-center">
                  <div class="col-xl-12 col-lg-12">
                     <div class="signup__boxes">
                        <form class="signup__form pt__10" action="{{ route('challan.store') }}" method="POST">
                                @csrf
                           <div class="row g-4 justify-content-center">

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="company_id">Select Client</label>
                                    <select name="company_id" class="" id="company_id" required>
                                        <option value="">Select Company</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->id }}"  {{ $company->id == $selectedclient->id ? 'selected' : '' }}>{{ $company->industry_name }}</option>
                                        @endforeach
                                    </select>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="challan_number">Challan Number</label>
                                    <input type="text" name="challan_number" class="" value="{{ old('challan_number', $challan_no) }}">
                                    @error('challan_number')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <div class="input__grp">
                                     <label for="date">Date</label>
                                    <input type="date" name="date" class="" value="{{ old('date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                    @error('date')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                  <div class="input__grp">
                                      <label for="purpose">Purpose</label>
                                      <select name="purpose" id="purpose" class="" required>
                                          <option value="">Select Financial Year</option>
                                          <option value="Machining">Machining</option>
                                          <option value="Washing">Washing</option>
                                          <option value="Plating">Plating</option>
                                      </select>

                                      @error('purpose')
                                          <span class="invalid-feedback" role="alert">
                                              <strong>{{ $message }}</strong>
                                          </span>
                                      @enderror
                                  </div>
                              </div>

                              <div class="col-lg-6" id="notes-box" style="display:none;">
                                  <div class="input__grp">
                                      <label for="notes">Notes</label>
                                      <textarea name="notes" id="notes" class="" rows="3"></textarea>

                                      @error('notes')
                                          <span class="invalid-feedback" role="alert">
                                              <strong>{{ $message }}</strong>
                                          </span>
                                      @enderror
                                  </div>
                              </div>

                              <!-- <div class="col-lg-6">
                                 <div class="input__grp">
                                     <label for="industry_name">Jobworker Name</label>
                                       <input type="text" id="industry_name" name="industry_name" value="" class="" readonly>
                                 </div>
                              </div> -->
                              <input type="hidden" id="industry_name" name="industry_name" value="{{ $selectedclient->industry_name }}" class="" readonly>
                              <div class="col-lg-6">
                                 <div class="input__grp">
                                     <label for="industry_name">Jobworker Number</label>
                                       <input type="text" id="industry_number" name="industry_number" value="{{ $selectedclient->industry_number }}" class="" readonly>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                     <label for="industry_name">Jobworker GST Number</label>
                                       <input type="text" id="industry_gstin" name="industry_gstin" value="{{ $selectedclient->industry_gstin }}" class="" readonly>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                     <label for="industry_name">Jobworker Address</label>
                                       <input type="text" id="industry_address" name="industry_address" value="{{ $selectedclient->industry_address }}" class="" readonly>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="vehicle_no">Vehicle Number</label>
                                    <input type="text" name="vehicle_no" class="">
                                    @error('vehicle_no')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="no_of_packages">No Of Packages</label>
                                    <input type="text" name="no_of_packages" class="">
                                    @error('no_of_packages')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <!-- <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="item_name">Item Name</label>
                                    <input type="text" name="item_name" class="">
                                    @error('item_name')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="hsn_code">HSN Code</label>
                                    <input type="text" name="hsn_code" class="">
                                    @error('hsn_code')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="price_per_kg">Price per Kilo/gram</label>
                                    <input type="number" step="0.01" id="price_per_kg" name="price_per_kg" class="" required>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="total_qty">Total Quantity (KG)</label>
                                    <input type="number" step="0.001" name="total_qty" id="total_qty" class="" required>
                                    @error('total_qty')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="total_value">Total Value</label>
                                    <input type="number" step="0.01" name="total_value" id="total_value" class="" readonly>
                                    @error('total_value')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div> -->
                              <div class="col-12">
                                  <div class="d-flex justify-content-between align-items-center mb-2">
                                      <h5>Challan Items</h5>
                                      <button type="button" class="btn btn-sm btn-success" id="addItemBtn">+ Add Item</button>
                                  </div>

                                  <div id="itemsContainer">
                                      <div class="row g-3 item-row">
                                          <div class="col-lg-3">
                                              <div class="input__grp">
                                                  <label>Item Name</label>
                                                  <input type="text" name="items[0][item_name]" class="form-control" required>
                                              </div>
                                          </div>
                                          <div class="col-lg-2">
                                              <div class="input__grp">
                                                  <label>HSN Code</label>
                                                  <input type="text" name="items[0][hsn_code]" class="form-control">
                                              </div>
                                          </div>
                                          <div class="col-lg-2">
                                              <div class="input__grp">
                                                  <label>Price per KG</label>
                                                  <input type="number" step="0.01" name="items[0][price_per_kg]" class="form-control price-per-kg price_per_kg" required>
                                              </div>
                                          </div>
                                          <div class="col-lg-2">
                                              <div class="input__grp">
                                                  <label>Total Qty (KG)</label>
                                                  <input type="number" step="0.001" name="items[0][total_qty]" class="form-control qty total_qty" required>
                                              </div>
                                          </div>
                                          <div class="col-lg-2">
                                              <div class="input__grp">
                                                  <label>Total Value</label>
                                                  <input type="number" step="0.01" name="items[0][total_value]" class="form-control total_value" readonly>
                                              </div>
                                          </div>
                                          <div class="col-lg-1 d-flex align-items-end">
                                              <button type="button" class="btn btn-danger removeItemBtn">X</button>
                                          </div>
                                      </div>
                                  </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                   <label for="cgst">CGST (%)</label>
                                    <input type="number" sstep="0.01" name="cgst" id="cgst" value="9" class="" required>
                                    @error('cgst')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="sgst">SGST (%)</label>
                                    <input type="number" step="0.01" name="sgst" id="sgst" value="9" class="" required>
                                    @error('sgst')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="total_tax">Total Tax (₹)</label>
                                    <input type="number" step="0.01" name="total_tax" id="total_tax" class="" readonly>
                                 </div>
                              </div>

                              <div class="col-lg-6">
                                 <div class="input__grp">
                                    <label for="grand_total">Grand Total (₹)</label>
                                    <input type="number" step="0.01" name="grand_total" id="grand_total" class="" readonly>
                                 </div>
                              </div>

                              <div class="col-lg-12">
                                 <div class="input__grp">
                                    <label for="description">Description</label>
                                    <textarea class="" rows="3" id="description" name="description" placeholder="Your message..."></textarea>
                                    @error('description')
                                      <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                      </span>
                                     @enderror
                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <div class="input__grp mt-2 text-center">
                                    <button type="submit" class="cmn__btn">
                                    <span>
                                    Save Challan
                                    </span>
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div>
</div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
@push('scripts')
<script>
$(document).ready(function() {
   $(document).on('input', '.price_per_kg, .total_qty', function() {
  calculateItemTotal($(this).closest('tr'));
  calculateAllTotals();
});

// Single item row calculation
function calculateItemTotal(row) {
  let qty = parseFloat(row.find('.total_qty').val()) || 0;
  let price = parseFloat(row.find('.price_per_kg').val()) || 0;
  let totalValue = qty * price;
  row.find('.total_value').val(totalValue.toFixed(2));
}

// Calculate totals, GST, grand total
function calculateAllTotals() {
  let totalValueSum = 0;

  // Sum total_value for all items
  $('.total_value').each(function() {
    let val = parseFloat($(this).val()) || 0;
    totalValueSum += val;
  });

  // Set the cumulative total
  let cgstRate = parseFloat($('#cgst').val()) || 0;
  let sgstRate = parseFloat($('#sgst').val()) || 0;

  let cgstAmount = (totalValueSum * cgstRate) / 100;
  let sgstAmount = (totalValueSum * sgstRate) / 100;
  let totalTax = cgstAmount + sgstAmount;

  let grandTotal = totalValueSum + totalTax;

  $('#total_tax').val(totalTax.toFixed(2));
  $('#grand_total').val(grandTotal.toFixed(2));
}

// GST/SGST input changes also trigger re-calculation
$('#cgst, #sgst').on('input', function() {
  calculateAllTotals();
});
   $('#purpose').on('change', function() {
        var selectedPurpose = $(this).val();

        if (selectedPurpose !== '') {
            $('#notes-box').show(); // Show the notes box if a purpose is selected
        } else {
            $('#notes-box').hide(); // Hide if no purpose is selected
            $('#notes').val('');    // Optionally clear notes when hiding
        }
    });

   /*if (selectedPurpose !== '') {
       $('#notes-box').show();
       $('#notes').attr('required', true);
   } else {
       $('#notes-box').hide();
       $('#notes').removeAttr('required');
       $('#notes').val('');
   }*/

    $('#company_id').on('change', function() {
        var companyId = $(this).val();
        if (companyId) {
            $.ajax({
                url: "{{ route('get.company.details') }}",
                type: "GET",
                data: { id: companyId },
                success: function(response) {
                    // Fill in the fields with the returned data
                    $('#industry_name').val(response.industry_name);
                    $('#industry_number').val(response.industry_number);
                    $('#industry_gstin').val(response.industry_gstin);
                    $('#industry_address').val(response.industry_address);
                },
                error: function() {
                    alert('Company details not found!');
                }
            });
        } else {
            // Clear fields if no company selected
            $('#industry_name').val('');
            $('#challan_number').val('');
            $('#address').val('');
        }
    });
});
let itemIndex = 1;

document.getElementById('addItemBtn').addEventListener('click', function () {
    const container = document.getElementById('itemsContainer');
    
    const newItemRow = document.createElement('div');
    newItemRow.classList.add('row', 'g-3', 'item-row', 'mt-2');

    newItemRow.innerHTML = `
        <div class="col-lg-3">
            <div class="input__grp">
                <label>Item Name</label>
                <input type="text" name="items[${itemIndex}][item_name]" class="form-control" required>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="input__grp">
                <label>HSN Code</label>
                <input type="text" name="items[${itemIndex}][hsn_code]" class="form-control">
            </div>
        </div>
        <div class="col-lg-2">
            <div class="input__grp">
                <label>Price per KG</label>
                <input type="number" step="0.01" name="items[${itemIndex}][price_per_kg]" class="form-control price-per-kg" required>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="input__grp">
                <label>Total Qty (KG)</label>
                <input type="number" step="0.001" name="items[${itemIndex}][total_qty]" class="form-control qty" required>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="input__grp">
                <label>Total Value</label>
                <input type="number" step="0.01" name="items[${itemIndex}][total_value]" class="form-control total-value" readonly>
            </div>
        </div>
        <div class="col-lg-1 d-flex align-items-end">
            <button type="button" class="btn btn-danger removeItemBtn">X</button>
        </div>
    `;

    container.appendChild(newItemRow);

    itemIndex++;
});

// Remove button functionality (event delegation)
document.getElementById('itemsContainer').addEventListener('click', function (e) {
    if (e.target && e.target.classList.contains('removeItemBtn')) {
        e.target.closest('.item-row').remove();
        calculateAllTotals();
    }
});

// Auto-calculate total_value (price_per_kg * total_qty)
document.getElementById('itemsContainer').addEventListener('input', function (e) {
    if (e.target.classList.contains('price-per-kg') || e.target.classList.contains('qty')) {
        const row = e.target.closest('.item-row');
        const price = parseFloat(row.querySelector('.price-per-kg').value) || 0;
        const qty = parseFloat(row.querySelector('.qty').value) || 0;
        const total = (price * qty).toFixed(2);

        row.querySelector('.total-value').value = total;
    }
});

</script>
@endpush
@endsection





<div class="container">
    <h2>Create Challan</h2>

    <form action="{{ route('challans.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="challan_number">Challan Number</label>
            <input type="text" name="challan_number" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="date">Date</label>
            <input type="date" name="date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="company_id">Select Company</label>
            <select name="company_id" class="form-control" required>
                @foreach($companies as $company)
                    <option value="{{ $company->id }}">{{ $company->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="financial_year_id">Select Financial Year</label>
            <select name="financial_year_id" class="form-control" required>
                @foreach($financialYears as $year)
                    <option value="{{ $year->id }}">{{ $year->year }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="jobworker_id">Select Job Worker</label>
            <select name="jobworker_id" class="form-control" required>
                @foreach($jobworkers as $worker)
                    <option value="{{ $worker->id }}">{{ $worker->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="vehicle_no">Vehicle Number</label>
            <input type="text" name="vehicle_no" class="form-control">
        </div>

        <div class="mb-3">
            <label for="total_qty">Total Quantity</label>
            <input type="number" step="0.01" name="total_qty" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="total_value">Total Value</label>
            <input type="number" step="0.01" name="total_value" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="cgst">CGST</label>
            <input type="number" step="0.01" name="cgst" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="sgst">SGST</label>
            <input type="number" step="0.01" name="sgst" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="description">Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Save Challan</button>
    </form>
</div>




<!--home two-->
            <div class="common__body__section">
               <div class="common__body__head pb__20">
                  <h4>
                     Email Template [1]
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblocksh2" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabh2" data-bs-toggle="pill" data-bs-target="#pills-homeblocksh2" type="button" role="tab" aria-controls="pills-homeblocksh2" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabh2" data-bs-toggle="pill" data-bs-target="#pills-profileblcoksh2" type="button" role="tab" aria-controls="pills-profileblcoksh2" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                     </ul>
               </div>
               <div class="tab-content" id="pills-tabContent">
                  <div class="tab-pane fade show active" id="pills-homeblocksh2" role="tabpanel" aria-labelledby="pills-home-tabh2">
                     <!-- Home two Here -->
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__email">
                                       <div class="emailrecharge__head d-flex align-items-center justify-content-between">
                                          <h3>
                                             Rechargio
                                          </h3>
                                          <a href="javacript:void(0)">
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </a>
                                       </div>
                                       <span class="leslie">
                                          Hey Leslie Alexander,
                                       </span>
                                       <div class="confirmed">
                                          <input class="form-check-input" type="checkbox" id="confired">
                                          <label class="form-check-label" for="confired">
                                             Thank you! Your reservation has been confirmed.
                                          </label>
                                       </div>
                                       <p>
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice number
                                             </span>
                                             <span class="counting">
                                                325546744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Order Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Hire's Nmae:
                                          </span>
                                          <h5 class="name">
                                             Leslie Alexander
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                21
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="1e70686a30776d6d6a30706b6a7b5e79737f7772307d7173">[email&#160;protected]</a>
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Address
                                             </span>
                                             <span class="counting">
                                                Royal Ln. Mesa, New Jersey
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Order Summary</h5>
                                       <div class="order__table__fluid">
                                          <div class="order__table__items bg__add">
                                             <span>
                                                Recipient No
                                             </span>
                                             <span>
                                                Operrator
                                             </span>
                                             <span>
                                                Receive amount
                                             </span>
                                             <span>
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                (406) 555-0120
                                             </span>
                                             <span>
                                                AT & T
                                             </span>
                                             <span>
                                                $4531.00
                                             </span>
                                             <span>
                                                $4531.00
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <div class="getway__wrapper">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction Date :
                                          </span>
                                          <span class="subtrans">
                                             05/12/2020
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gateway :
                                          </span>
                                          <span class="subtrans">
                                             Credit Card
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction ID :
                                          </span>
                                          <span class="subtrans">
                                             321 565 954
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Amount :
                                          </span>
                                          <span class="subtrans">
                                             $362.00
                                          </span>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point justify-content-center d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span class="print">
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <!-- Home two End -->
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcoksh2" role="tabpanel" aria-labelledby="pills-profile-tabh2">
                  <pre><code class="language-markup"><!--
                    <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__email">
                                       <div class="emailrecharge__head d-flex align-items-center justify-content-between">
                                          <h3>
                                             Rechargio
                                          </h3>
                                          <a href="javacript:void(0)">
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </a>
                                       </div>
                                       <span class="leslie">
                                          Hey Leslie Alexander,
                                       </span>
                                       <div class="confirmed">
                                          <input class="form-check-input" type="checkbox" id="confired">
                                          <label class="form-check-label" for="confired">
                                             Thank you! Your reservation has been confirmed.
                                          </label>
                                       </div>
                                       <p>
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice number
                                             </span>
                                             <span class="counting">
                                                325546744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Order Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Hire's Nmae:
                                          </span>
                                          <h5 class="name">
                                             Leslie Alexander
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                21
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                nvt.isst.nute@gmail.com
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Address
                                             </span>
                                             <span class="counting">
                                                Royal Ln. Mesa, New Jersey
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Order Summary</h5>
                                       <div class="order__table__fluid">
                                          <div class="order__table__items bg__add">
                                             <span>
                                                Recipient No
                                             </span>
                                             <span>
                                                Operrator
                                             </span>
                                             <span>
                                                Receive amount
                                             </span>
                                             <span>
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                (406) 555-0120
                                             </span>
                                             <span>
                                                AT & T
                                             </span>
                                             <span>
                                                $4531.00
                                             </span>
                                             <span>
                                                $4531.00
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <div class="getway__wrapper">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction Date :
                                          </span>
                                          <span class="subtrans">
                                             05/12/2020
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gateway :
                                          </span>
                                          <span class="subtrans">
                                             Credit Card
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction ID :
                                          </span>
                                          <span class="subtrans">
                                             321 565 954
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Amount :
                                          </span>
                                          <span class="subtrans">
                                             $362.00
                                          </span>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point justify-content-center d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span class="print">
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home three-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Hotel Invoce
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblocksh3" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabh3" data-bs-toggle="pill" data-bs-target="#pills-homeblocksh3" type="button" role="tab" aria-controls="pills-homeblocksh3" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabh3" data-bs-toggle="pill" data-bs-target="#pills-profileblcoksh3" type="button" role="tab" aria-controls="pills-profileblcoksh3" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                     </ul>
               </div>
               <div class="tab-content" id="pills-tabContent3">
                  <div class="tab-pane fade show active" id="pills-homeblocksh3" role="tabpanel" aria-labelledby="pills-home-tabh3">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper pb__30 mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <h5 class="name fw-700 dtext">
                                             Invoice
                                          </h5>
                                          <span class="hirename fz-16 fw-400 dtext lato">
                                             Invoice Number - 91735
                                          </span>
                                       </div>
                                    </div>
                                    <ul class="hotelinvocie__bookngid d-flex mb__30 justify-content-between">
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Guest Name:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Theresa Webb
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Hotel Details:
                                             </span>
                                             <span class="pratext fz-16 fw-400 lato dtext">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking ID:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                1646464946
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking Date:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Payment Mode:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                               Credit Card
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check In:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                22/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check Out:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Rooms:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                               1
                                             </span>
                                          </span>
                                       </li>
                                    </ul>
                                    <div class="invoice__scrool">
                                       <table class="hotel__invoicetable mb__30">
                                          <tr class="headfoot bgwhite">
                                             <th>Description</th>
                                             <th>Price</th>
                                             <th>Vat%</th>
                                             <th>Total</th>
                                          </tr>
                                          <tbody>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$442</td>
                                             <td>5%</td>
                                             <td>$452</td>
                                          </tr>
                                          <tr class="bgwhite">
                                             <td>Extra Guests Cost</td>
                                             <td>$0</td>
                                             <td>0%</td>
                                             <td>$0</td>
                                          </tr>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$15</td>
                                             <td>2%</td>
                                             <td>$20</td>
                                          </tr>
                                          </tbody>
                                          <tr class="headfoot bgwhite">
                                             <th>Total</th>
                                             <th>0</th>
                                             <th>0</th>
                                             <th>$472</th>
                                          </tr>
                                       </table>
                                    </div>
                                    <p class="d-flex mb__30 align-items-center fz-16 lato dtext gap-2">
                                       <span class="fz-18 fw-600 lato dtext">
                                          Please Note:
                                       </span>
                                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum...
                                    </p>
                                    <ul class="hotel__contact__invoice d-flex align-items-center gap-3 justify-content-between">
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/call.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                (406) 555-0120
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                (704) 555-0127
                                             </span>
                                          </a>
                                       </li>
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/message.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                <span class="__cf_email__" data-cfemail="590d303c37352d373d193e34383035773a3634">[email&#160;protected]</span>
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                <span class="__cf_email__" data-cfemail="afebcacdc7c0dbefc8cec2c6c381ccc0c2">[email&#160;protected]</span>
                                             </span>
                                          </a>
                                       </li>
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/parker-map.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                Parker Rd.
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Allentown
                                             </span>
                                          </a>
                                       </li>
                                    </ul>
                                    <p class="note mt__30">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcoksh3" role="tabpanel" aria-labelledby="pills-profile-tabh3">
                  <pre><code class="language-markup"><!--
                    <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper pb__30 mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <h5 class="name fw-700 dtext">
                                             Invoice
                                          </h5>
                                          <span class="hirename fz-16 fw-400 dtext lato">
                                             Invoice Number - 91735
                                          </span>
                                       </div>
                                    </div>
                                    <ul class="hotelinvocie__bookngid d-flex mb__30 justify-content-between">
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Guest Name:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Theresa Webb
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Hotel Details:
                                             </span>
                                             <span class="pratext fz-16 fw-400 lato dtext">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking ID:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                1646464946
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking Date:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Payment Mode:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                             Credit Card
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check In:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                22/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check Out:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Rooms:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                             1
                                             </span>
                                          </span>
                                       </li>
                                    </ul>
                                    <div class="invoice__scrool">
                                       <table class="hotel__invoicetable mb__30">
                                          <tr class="headfoot bgwhite">
                                             <th>Description</th>
                                             <th>Price</th>
                                             <th>Vat%</th>
                                             <th>Total</th>
                                          </tr>
                                          <tbody>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$442</td>
                                             <td>5%</td>
                                             <td>$452</td>
                                          </tr>
                                          <tr class="bgwhite">
                                             <td>Extra Guests Cost</td>
                                             <td>$0</td>
                                             <td>0%</td>
                                             <td>$0</td>
                                          </tr>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$15</td>
                                             <td>2%</td>
                                             <td>$20</td>
                                          </tr>
                                          </tbody>
                                          <tr class="headfoot bgwhite">
                                             <th>Total</th>
                                             <th>0</th>
                                             <th>0</th>
                                             <th>$472</th>
                                          </tr>
                                       </table>
                                    </div>
                                    <p class="d-flex mb__30 align-items-center fz-16 lato dtext gap-2">
                                       <span class="fz-18 fw-600 lato dtext">
                                          Please Note:
                                       </span>
                                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum...
                                    </p>
                                    <ul class="hotel__contact__invoice d-flex align-items-center gap-3 justify-content-between">
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/call.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                (406) 555-0120
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                (704) 555-0127
                                             </span>
                                          </a>
                                       </li>
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/message.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                Tienltnd@gmail.com
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Debhot@gamil.com
                                             </span>
                                          </a>
                                       </li>
                                       <li class="d-flex align-items-center gap-3">
                                          <span class="icon d-flex align-items-center justify-content-center">
                                             <img src="assets/img/svg/parker-map.svg" alt="svg">
                                          </span>
                                          <a href="#0">
                                             <span class="fz-16 fw-400 lato dtext d-block">
                                                Parker Rd.
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Allentown
                                             </span>
                                          </a>
                                       </li>
                                    </ul>
                                    <p class="note mt__30">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home four-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Hotel Email
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblocksh4" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabh4" data-bs-toggle="pill" data-bs-target="#pills-homeblocksh4" type="button" role="tab" aria-controls="pills-homeblocksh4" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabh4" data-bs-toggle="pill" data-bs-target="#pills-profileblcoksh4" type="button" role="tab" aria-controls="pills-profileblcoksh4" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContent4">
                  <div class="tab-pane fade show active" id="pills-homeblocksh4" role="tabpanel" aria-labelledby="pills-home-tabh4">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                         <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Thrresa Webb,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <input class="form-check-input" type="checkbox" id="saveForNextcard" checked>
                                           <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <ul class="hotelinvocie__bookngid d-flex mb__30 justify-content-between">
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Guest Name:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Theresa Webb
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Hotel Details:
                                             </span>
                                             <span class="pratext fz-16 fw-400 lato dtext">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking ID:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                1646464946
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking Date:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Payment Mode:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                               Credit Card
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check In:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                22/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check Out:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Rooms:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                               1
                                             </span>
                                          </span>
                                       </li>
                                    </ul>
                                    <div class="invoice__scrool">
                                       <table class="hotel__invoicetable mb__30">
                                          <tr class="headfoot bgwhite">
                                             <th>Description</th>
                                             <th>Price</th>
                                             <th>Vat%</th>
                                             <th>Total</th>
                                          </tr>
                                          <tbody>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$442</td>
                                             <td>5%</td>
                                             <td>$452</td>
                                          </tr>
                                          <tr class="bgwhite">
                                             <td>Extra Guests Cost</td>
                                             <td>$0</td>
                                             <td>0%</td>
                                             <td>$0</td>
                                          </tr>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$15</td>
                                             <td>2%</td>
                                             <td>$20</td>
                                          </tr>
                                          </tbody>
                                          <tr class="headfoot bgwhite">
                                             <th>Total</th>
                                             <th>0</th>
                                             <th>0</th>
                                             <th>$472</th>
                                          </tr>
                                       </table>
                                    </div>
                                    <p class="d-flex bbottom pb__30 justify-content-center mb__30 align-items-center fz-16 lato dtext gap-2">
                                       <span class="fz-18 fw-600 lato dtext">
                                          Please Note:
                                       </span>
                                       Additional supplements are not added to this total.
                                    </p>
                                    <p class="note mt__30 text-center">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="text-center">
                                       <a href="contact.html" class="cmn__btn">
                                          <span>
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcoksh4" role="tabpanel" aria-labelledby="pills-profile-tabh4">
                  <pre><code class="language-markup"><!--
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                       <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Thrresa Webb,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <input class="form-check-input" type="checkbox" id="saveForNextcard" checked>
                                          <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <ul class="hotelinvocie__bookngid d-flex mb__30 justify-content-between">
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Guest Name:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                Theresa Webb
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Hotel Details:
                                             </span>
                                             <span class="pratext fz-16 fw-400 lato dtext">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking ID:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                1646464946
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Booking Date:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Payment Mode:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                             Credit Card
                                             </span>
                                          </span>
                                       </li>
                                       <li>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check In:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                22/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item d-block mb__15">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Check Out:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                                23/12/2025
                                             </span>
                                          </span>
                                          <span class="bookinid__item">
                                             <span class="d-block mb-1 dtext fw-600 fz-18 lato">
                                                Rooms:
                                             </span>
                                             <span class="fz-16 fw-400 lato dtext">
                                             1
                                             </span>
                                          </span>
                                       </li>
                                    </ul>
                                    <div class="invoice__scrool">
                                       <table class="hotel__invoicetable mb__30">
                                          <tr class="headfoot bgwhite">
                                             <th>Description</th>
                                             <th>Price</th>
                                             <th>Vat%</th>
                                             <th>Total</th>
                                          </tr>
                                          <tbody>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$442</td>
                                             <td>5%</td>
                                             <td>$452</td>
                                          </tr>
                                          <tr class="bgwhite">
                                             <td>Extra Guests Cost</td>
                                             <td>$0</td>
                                             <td>0%</td>
                                             <td>$0</td>
                                          </tr>
                                          <tr>
                                             <td>Room Charges</td>
                                             <td>$15</td>
                                             <td>2%</td>
                                             <td>$20</td>
                                          </tr>
                                          </tbody>
                                          <tr class="headfoot bgwhite">
                                             <th>Total</th>
                                             <th>0</th>
                                             <th>0</th>
                                             <th>$472</th>
                                          </tr>
                                       </table>
                                    </div>
                                    <p class="d-flex bbottom pb__30 justify-content-center mb__30 align-items-center fz-16 lato dtext gap-2">
                                       <span class="fz-18 fw-600 lato dtext">
                                          Please Note:
                                       </span>
                                       Additional supplements are not added to this total.
                                    </p>
                                    <p class="note mt__30 text-center">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="text-center">
                                       <a href="contact.html" class="cmn__btn">
                                          <span>
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home five-->
            <div class="common__body__section pb__20">
               <div class="common__body__head pb__20">
                  <h4>
                    Flight Invoice
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblocksh5" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabh5" data-bs-toggle="pill" data-bs-target="#pills-homeblocksh5" type="button" role="tab" aria-controls="pills-homeblocksh5" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabh5" data-bs-toggle="pill" data-bs-target="#pills-profileblcoksh5" type="button" role="tab" aria-controls="pills-profileblcoksh5" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContent5trd">
                  <div class="tab-pane fade show active" id="pills-homeblocksh5" role="tabpanel" aria-labelledby="pills-home-tabh5">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__40">
                                       <div class="invoice__leftbox">
                                          <h3 class="upper dtext">
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Account number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Invoice To :
                                          </span>
                                          <h5 class="name">
                                             Mr. Jonson Hawk
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ef81999bc1869c9c9bc1819a9b8aaf88828e8683c18c8082">[email&#160;protected]</a>
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Web
                                             </span>
                                             <span class="counting">
                                                https://www.ifeng.com/
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Flight Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <div class="transaction__dating mb__40 d-flex align-items-center">
                                       <img src="assets/img/details/reapp.png" class="reapp" alt="img">
                                       <ul class="tran__date">
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Transaction Date
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                11-12-22
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Gateway
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                Credit Card
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Transaction ID
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                321 565 788
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Amount                 :
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                $1583.20
                                             </span>
                                          </li>
                                       </ul>
                                       <img src="assets/img/details/qr.jpg" class="qu__code" alt="qr-code">
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcoksh5" role="tabpanel" aria-labelledby="pills-profile-tabh5">
                  <pre><code class="language-markup"><!--
                   <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__40">
                                       <div class="invoice__leftbox">
                                          <h3 class="upper dtext">
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Account number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Invoice To :
                                          </span>
                                          <h5 class="name">
                                             Mr. Jonson Hawk
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                nvt.isst.nute@gmail.com
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Web
                                             </span>
                                             <span class="counting">
                                                https://www.ifeng.com/
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Flight Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <div class="transaction__dating mb__40 d-flex align-items-center">
                                       <img src="assets/img/details/reapp.png" class="reapp" alt="img">
                                       <ul class="tran__date">
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Transaction Date
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                11-12-22
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Gateway
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                Credit Card
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Transaction ID
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                321 565 788
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center">
                                             <span class="blodtext fz-18 fw-600 lato dtext">
                                                Amount                 :
                                             </span>
                                             <span class="fz-16 lato fw-400 dtext">
                                                $1583.20
                                             </span>
                                          </li>
                                       </ul>
                                       <img src="assets/img/details/qr.jpg" class="qu__code" alt="qr-code">
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home six-->
            <div class="common__body__section pb__20">
               <div class="common__body__head pb__20">
                  <h4>
                     Flight Email
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblocksh5ts" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabh5ts" data-bs-toggle="pill" data-bs-target="#pills-homeblocksh5ts" type="button" role="tab" aria-controls="pills-homeblocksh5ts" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabh5ts" data-bs-toggle="pill" data-bs-target="#pills-profileblcoksh5ts" type="button" role="tab" aria-controls="pills-profileblcoksh5ts" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContent5trb">
                  <div class="tab-pane fade show active" id="pills-homeblocksh5ts" role="tabpanel" aria-labelledby="pills-home-tabh5ts">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                         <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Thrresa Webb,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                           <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="booking__refer">
                                      <div class="d-flex mb-1 align-items-center gap-3">
                                          <span class="fz-18 fw-600 lato dtext">
                                             Booking Reference Number :
                                          </span>
                                          <span class="fz-16 lato dtext">
                                             325 546 744
                                          </span>
                                      </div>
                                      <div class="d-flex mb-1 align-items-center gap-3">
                                          <span class="fz-18 fw-600 lato dtext">
                                             Booking Status
                                          </span>
                                          <span class="fz-16 lato dtext">
                                             07/11/2019
                                          </span>
                                       </div>
                                       <p class="fz-16 fw-400 dtext lato">
                                          Thank you for booking your travel itinerary with Rechargio.
                                       </p>
                                    </div>
                                    <div class="booking__number mt__30 mb__30 row">
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Booking Date :</span>
                                          <span class="fz-16 fw-400 lato dtext">15-12-22</span>
                                       </div>
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Booking No :</span>
                                          <span class="fz-16 fw-400 lato dtext">236 245 265</span>
                                       </div>
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Payment :</span>
                                          <span class="fz-16 fw-400 lato dtext">Credit Card</span>
                                       </div>
                                    </div>
                                    <div class="passenger__infos">
                                       <h5 class="dtext fw-400 mb__20">
                                          Passenger Information
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                            <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Nmae
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Confirmation
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Seat
                                                </span>
                                            </div>
                                          </div>
                                          <div class="bgwhite">
                                             <div class="p__inf d-flex align-items-center justify-content-between">
                                                 <span class="fz-16 fw-400 lato d-block dtext">
                                                    Neil Mack
                                                 </span>
                                                 <span class="fz-16 fw-400 lato d-block dtext">
                                                    #215552221
                                                 </span>
                                                 <span class="fz-16 fw-400 lato d-block dtext">
                                                    12B
                                                 </span>
                                             </div>
                                           </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos priceb mb__20">
                                       <h5 class="dtext fw-400 mb__20">
                                          Flight Details
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                            <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Flight
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Depart
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Arrive
                                                </span>
                                            </div>
                                          </div>
                                          <div class="row justify-content-center bgwhite">
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                 <span class="d-block">
                                                    <img src="assets/img/payment/deltas.jpg" alt="img">
                                                 </span>
                                                 <span class="fz-16 fw-400 lato d-block dtext">
                                                    Delta Air Lines
                                                 </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   New York 20-12-22, Sat 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   01:50 PMTravel Time: 1h
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   30mCabin Class: 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   EconomySeat: 12B
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Dubai, 21-12-22, Sat 19:38
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   PMBooking Code: SPlane 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Type: 772
                                                </span>
                                             </div>
                                           </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos">
                                       <h5 class="dtext fw-400 mb__20">
                                          Passenger Information
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                            <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Nmae
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Confirmation
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Seat
                                                </span>
                                            </div>
                                          </div>
                                          <div class="bgwhite">
                                             <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Neil Mack
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   #215552221
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   12B
                                                </span>
                                             </div>
                                           </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos ">
                                       <h5 class="dtext fw-400 mb__20">
                                          Flight Details
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                            <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Flight
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Depart
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Arrive
                                                </span>
                                            </div>
                                          </div>
                                          <div class="row justify-content-center bgwhite">
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                 <span class="d-block">
                                                    <img src="assets/img/payment/deltas.jpg" alt="img">
                                                 </span>
                                                 <span class="fz-16 fw-400 lato d-block dtext">
                                                    Delta Air Lines
                                                 </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   New York 20-12-22, Sat 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   01:50 PMTravel Time: 1h
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   30mCabin Class: 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   EconomySeat: 12B
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Dubai, 21-12-22, Sat 19:38
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   PMBooking Code: SPlane 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Type: 772
                                                </span>
                                             </div>
                                           </div>
                                       </div>
                                    </div>
                                    <p class="note mt__30 text-center">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="text-center">
                                       <a href="contact.html" class="cmn__btn">
                                          <span>
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcoksh5ts" role="tabpanel" aria-labelledby="pills-profile-tabh5ts">
                  <pre><code class="language-markup"><!--
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper hotel__invoice">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                       <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Thrresa Webb,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                          <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="booking__refer">
                                    <div class="d-flex mb-1 align-items-center gap-3">
                                          <span class="fz-18 fw-600 lato dtext">
                                             Booking Reference Number :
                                          </span>
                                          <span class="fz-16 lato dtext">
                                             325 546 744
                                          </span>
                                    </div>
                                    <div class="d-flex mb-1 align-items-center gap-3">
                                          <span class="fz-18 fw-600 lato dtext">
                                             Booking Status
                                          </span>
                                          <span class="fz-16 lato dtext">
                                             07/11/2019
                                          </span>
                                       </div>
                                       <p class="fz-16 fw-400 dtext lato">
                                          Thank you for booking your travel itinerary with Rechargio.
                                       </p>
                                    </div>
                                    <div class="booking__number mt__30 mb__30 row">
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Booking Date :</span>
                                          <span class="fz-16 fw-400 lato dtext">15-12-22</span>
                                       </div>
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Booking No :</span>
                                          <span class="fz-16 fw-400 lato dtext">236 245 265</span>
                                       </div>
                                       <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                          <span class="fz-18 mb-1 d-block fw-600 lato dtext">Payment :</span>
                                          <span class="fz-16 fw-400 lato dtext">Credit Card</span>
                                       </div>
                                    </div>
                                    <div class="passenger__infos">
                                       <h5 class="dtext fw-400 mb__20">
                                          Passenger Information
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                          <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Nmae
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Confirmation
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Seat
                                                </span>
                                          </div>
                                          </div>
                                          <div class="bgwhite">
                                             <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Neil Mack
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   #215552221
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   12B
                                                </span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos priceb mb__20">
                                       <h5 class="dtext fw-400 mb__20">
                                          Flight Details
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                          <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Flight
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Depart
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Arrive
                                                </span>
                                          </div>
                                          </div>
                                          <div class="row justify-content-center bgwhite">
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="d-block">
                                                   <img src="assets/img/payment/deltas.jpg" alt="img">
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Delta Air Lines
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   New York 20-12-22, Sat 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   01:50 PMTravel Time: 1h
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   30mCabin Class: 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   EconomySeat: 12B
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Dubai, 21-12-22, Sat 19:38
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   PMBooking Code: SPlane 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Type: 772
                                                </span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos">
                                       <h5 class="dtext fw-400 mb__20">
                                          Passenger Information
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                          <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Nmae
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Confirmation
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Seat
                                                </span>
                                          </div>
                                          </div>
                                          <div class="bgwhite">
                                             <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Neil Mack
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   #215552221
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   12B
                                                </span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="passenger__infos ">
                                       <h5 class="dtext fw-400 mb__20">
                                          Flight Details
                                       </h5>
                                       <div class="p__inforbox mb__30">
                                          <div class="tablebg">
                                          <div class="p__inf d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Flight
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Depart
                                                </span>
                                                <span class="fz-18 fw-600 lato d-block dtext">
                                                   Arrive
                                                </span>
                                          </div>
                                          </div>
                                          <div class="row justify-content-center bgwhite">
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="d-block">
                                                   <img src="assets/img/payment/deltas.jpg" alt="img">
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Delta Air Lines
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   New York 20-12-22, Sat 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   01:50 PMTravel Time: 1h
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   30mCabin Class: 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   EconomySeat: 12B
                                                </span>
                                             </div>
                                             <div class="tableitems pt__10 pb__10 col-xl-4 col-lg-6 col-md-6 col-sm-6">
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Dubai, 21-12-22, Sat 19:38
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   PMBooking Code: SPlane 
                                                </span>
                                                <span class="fz-16 fw-400 lato d-block dtext">
                                                   Type: 772
                                                </span>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <p class="note mt__30 text-center">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="text-center">
                                       <a href="contact.html" class="cmn__btn">
                                          <span>
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home hotel book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Train Invice
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs" type="button" role="tab" aria-controls="pills-homeblockshs" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs" type="button" role="tab" aria-controls="pills-profileblcokshs" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs">
                  <div class="tab-pane fade show active" id="pills-homeblockshs" role="tabpanel" aria-labelledby="pills-home-tabhs">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Booking Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Passenger Details:
                                          </span>
                                          <h5 class="name">
                                             Mr. Jonson Hawk
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                31
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="83edf5f7adeaf0f0f7adedf6f7e6c3e4eee2eaefade0ecee">[email&#160;protected]</a>
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Train Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs" role="tabpanel" aria-labelledby="pills-profile-tabhs">
                     <pre><code class="language-markup"><!--
                    
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Invoice number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Booking Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Passenger Details:
                                          </span>
                                          <h5 class="name">
                                             Mr. Jonson Hawk
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                31
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                nvt.isst.nute@gmail.com
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Train Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home flight book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Train Email
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs1" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs1" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs1" type="button" role="tab" aria-controls="pills-homeblockshs1" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs1" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs1" type="button" role="tab" aria-controls="pills-profileblcokshs1" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs1">
                  <div class="tab-pane fade show active" id="pills-homeblockshs1" role="tabpanel" aria-labelledby="pills-home-tabhs1">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                         <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Jonson Hawk,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                           <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <h5 class="dtext fw-700 passengertitle">
                                       Passenger Details 
                                    </h5>
                                    <div class="getway__wrapper">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction Date :
                                          </span>
                                          <span class="subtrans">
                                             05/12/2020
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gateway :
                                          </span>
                                          <span class="subtrans">
                                             Credit Card
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction ID :
                                          </span>
                                          <span class="subtrans">
                                             321 565 954
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Amount :
                                          </span>
                                          <span class="subtrans">
                                             $362.00
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Train Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items bgaddtwo">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box bgaddtwo">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs1" role="tabpanel" aria-labelledby="pills-profile-tabhs1">
                     <pre><code class="language-markup"><!--
                    
                   <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                       <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Jonson Hawk,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                          <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <h5 class="dtext fw-700 passengertitle">
                                       Passenger Details 
                                    </h5>
                                    <div class="getway__wrapper">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction Date :
                                          </span>
                                          <span class="subtrans">
                                             05/12/2020
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gateway :
                                          </span>
                                          <span class="subtrans">
                                             Credit Card
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Transaction ID :
                                          </span>
                                          <span class="subtrans">
                                             321 565 954
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Amount :
                                          </span>
                                          <span class="subtrans">
                                             $362.00
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Train Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items bgaddtwo">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box bgaddtwo">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home Train book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Bus Invoice
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs2" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs2" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs2" type="button" role="tab" aria-controls="pills-homeblockshs2" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs2buss" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs2buss" type="button" role="tab" aria-controls="pills-profileblcokshs2buss" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs2">
                  <div class="tab-pane fade show active" id="pills-homeblockshs2" role="tabpanel" aria-labelledby="pills-home-tabhs2">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Account number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Booking Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Passenger Details:
                                          </span>
                                          <h5 class="name">
                                             Mr. Jonson Hawk
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                31
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="c4aab2b0eaadb7b7b0eaaab1b0a184a3a9a5ada8eaa7aba9">[email&#160;protected]</a>
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Bus Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Base Fare
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Taxes & Fee
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $99.00
                                             </span>
                                             <span>
                                                $13
                                             </span>
                                             <span>
                                                $114.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs2buss" role="tabpanel" aria-labelledby="pills-profile-tabhs2buss">
                     <pre><code class="language-markup"><!--
                    
                   <section class="order__section pt__60 pb__60">
                     <div class="container">
                        <div class="row justify-content-center">
                           <div class="col-xxl-8 col-xl-10 col-lg-12">
                              <div class="order__wrappers invoice__wrapper">
                                 <div class="invoice__textwrapper mb__30">
                                    <div class="invoice__leftbox">
                                       <h3>
                                          Invoice
                                       </h3>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Account number
                                          </span>
                                          <span class="counting">
                                             325 546 744
                                          </span>
                                       </div>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Booking Date   
                                          </span>
                                          <span class="counting">
                                             07/11/2025
                                          </span>
                                       </div>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Payment Method
                                          </span>
                                          <span class="counting">
                                             Credit Card
                                          </span>
                                       </div>
                                    </div>
                                    <div class="invoice__righttbox">
                                       <span class="hirename">
                                          Passenger Details:
                                       </span>
                                       <h5 class="name">
                                          Mr. Jonson Hawk
                                       </h5>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Age
                                          </span>
                                          <span class="counting">
                                             31
                                          </span>
                                       </div>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Phone
                                          </span>
                                          <span class="counting">
                                             (684) 555-0102
                                          </span>
                                       </div>
                                       <div class="invoice__leftnumber">
                                          <span class="bage">
                                             Email
                                          </span>
                                          <span class="counting">
                                             nvt.isst.nute@gmail.com
                                          </span>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="invoice__journey mb__30">
                                    <h5 class="dtext border__bottom">
                                       Journey Details
                                    </h5>
                                    <div class="d-flex journey__invoicedata">
                                       <ul class="jou__data">
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Transactions ID
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                CDFF123476359
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Train No & Name
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Delta Express
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Booking Date
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                16-12-2022
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Class
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                AC_Chair
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                From
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                New York
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Departure
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                10:20 pm
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Distance
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                2856 Km
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Adult
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                1
                                             </span>
                                          </li>
                                       </ul>
                                       <ul class="jou__data jou__tadatwo">
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                PNR
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                445216232
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Date of journey
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                22-12-2022
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Mode of payment
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Credit Card
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Transaction
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Success
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                To
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Dubai
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Child
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                0
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Seats No
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                A(1)
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Payment Amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                $114
                                             </span>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                                 <div class="order__summary__wrapper mb__40">
                                    <div class="over__responsive">
                                    <h5 class="summary__title">Booking Summary</h5>
                                    <div class="order__table__fluid order__table__flight">
                                       <div class="order__table__items bg__add">
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Bus Details
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Base Fare
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Taxes & Fee
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Amount
                                          </span>
                                       </div>
                                       <div class="order__table__items">
                                          <span>
                                             Delta 71613 - 
                                          </span>
                                          <span>
                                             $99.00
                                          </span>
                                          <span>
                                             $13
                                          </span>
                                          <span>
                                             $114.00
                                          </span>
                                       </div>
                                       <div class="order__table__itemsflight pb__15">
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             Dubai To New York 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             Travel Date - Sun, 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             22 dec 22, 02:50 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             hrs
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__table__box">
                                       <div class="order__graph">
                                          <ul>
                                             <li>
                                                <span>Sub Total:</span>
                                                <span class="bg">$4531.00</span>
                                             </li>
                                             <li>
                                                <span>Promotional Code:</span>
                                                <span class="bg">0</span>
                                             </li>
                                             <li>
                                                <span>Total:</span>
                                                <span class="bg">$4531.00</span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    </div>
                                 </div>
                                 <p class="note">
                                    Note : This is computer generated receipt and does not require physical signature.
                                 </p>
                                 <div class="print__point__btn d-flex align-items-center gap-3">
                                    <a href="print" class="cmn__btn">
                                       <span>
                                          <i class="material-symbols-outlined">
                                             print
                                          </i>
                                       </span>
                                       <span class="print">
                                          Print
                                       </span>
                                    </a>
                                    <a href="print" class="cmn__btn">
                                       <span>
                                          <i class="material-symbols-outlined">
                                             download
                                          </i>
                                       </span>
                                       <span class="print">
                                          Download
                                       </span>
                                    </a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home Bus book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Bus Email
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs3" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs3" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs3" type="button" role="tab" aria-controls="pills-homeblockshs3" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs2tes" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs3tes" type="button" role="tab" aria-controls="pills-profileblcokshs3tes" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs3tre">
                  <div class="tab-pane fade show active" id="pills-homeblockshs3" role="tabpanel" aria-labelledby="pills-home-tabhs3">
                     <!-- Home Here -->
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                         <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Leslie Alexander,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                           <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <h5 class="dtext fw-700 passengertitle">
                                       Passenger Details 
                                    </h5>
                                    <div class="getway__wrapper getway__wrapperbus">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Name :
                                          </span>
                                          <span class="subtrans">
                                            Leslie Alexander
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Age :
                                          </span>
                                          <span class="subtrans">
                                             21
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gender :
                                          </span>
                                          <span class="subtrans">
                                             Male
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Phone :
                                          </span>
                                          <span class="subtrans">
                                             (654) 555-0102
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Email :
                                          </span>
                                          <span class="subtrans">
                                             <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="b6d8c0c298dcc5c5c298d8c3c2d3f6d1dbd7df98d5d9db">[email&#160;protected]</a>
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Bus Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items bgaddtwo">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box bgaddtwo">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point d-flex justify-content-center align-items-center">
                                       <a href="print.html" class="cmn__btn">
                                          <span class="print">
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <!-- Home End -->
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs3tes" role="tabpanel" aria-labelledby="pills-profile-tabhs2tes">
                     <pre><code class="language-markup"><!--
                    
                    <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                       <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Leslie Alexander,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                          <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Journey Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transactions ID
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   CDFF123476359
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Train No & Name
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Express
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Booking Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   16-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Class
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   AC_Chair
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   From
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Departure
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   10:20 pm
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Distance
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2856 Km
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Adult
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   PNR
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   445216232
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Date of journey
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-2022
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   To
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Dubai
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Child
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   0
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Seats No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A(1)
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center border__bottom justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Payment Amount
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $114
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <h5 class="dtext fw-700 passengertitle">
                                       Passenger Details 
                                    </h5>
                                    <div class="getway__wrapper getway__wrapperbus">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Name :
                                          </span>
                                          <span class="subtrans">
                                          Leslie Alexander
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Age :
                                          </span>
                                          <span class="subtrans">
                                             21
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gender :
                                          </span>
                                          <span class="subtrans">
                                             Male
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Phone :
                                          </span>
                                          <span class="subtrans">
                                             (654) 555-0102
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Email :
                                          </span>
                                          <span class="subtrans">
                                             nvt.jsst.nute@gmai.com
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Bus Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items bgaddtwo">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box bgaddtwo">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point d-flex justify-content-center align-items-center">
                                       <a href="print" class="cmn__btn">
                                          <span class="print">
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home Car book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Car Invoice
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs4" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs4" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs4" type="button" role="tab" aria-controls="pills-homeblockshs4" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs4" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs4" type="button" role="tab" aria-controls="pills-profileblcokshs4" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs3">
                  <div class="tab-pane fade show active" id="pills-homeblockshs4" role="tabpanel" aria-labelledby="pills-home-tabhs4">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Account number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Booking Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Fire's Name
                                          </span>
                                          <h5 class="name">
                                             Leslie Alexander
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                31
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="7f11090b51160c0c0b51110a0b1a3f18121e1613511c1012">[email&#160;protected]</a>
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Addres
                                             </span>
                                             <span class="counting">
                                                Royal Ln. Mesa, New Jersey
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Build the model
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Creta - MBW
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car category
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Enterprise
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Special
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Car on Self Drive
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent start Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent End Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   23-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Total Days
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car Regn. No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                  6651 EY9F
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Out KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1012
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   In KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2123
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Ttal km(s)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   356
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of Payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Security deposit
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $7413
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Licence Issued
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Passport No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A4455444
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Id Issuing City
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Car Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Base Fare
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Taxes & Fee
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $99.00
                                             </span>
                                             <span>
                                                $13
                                             </span>
                                             <span>
                                                $114.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print.html" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs4" role="tabpanel" aria-labelledby="pills-profile-tabhs4">
                     <pre><code class="language-markup"><!--
                    
                    <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row justify-content-center">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="order__wrappers invoice__wrapper">
                                    <div class="invoice__textwrapper mb__30">
                                       <div class="invoice__leftbox">
                                          <h3>
                                             Invoice
                                          </h3>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Account number
                                             </span>
                                             <span class="counting">
                                                325 546 744
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Booking Date   
                                             </span>
                                             <span class="counting">
                                                07/11/2025
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Payment Method
                                             </span>
                                             <span class="counting">
                                                Credit Card
                                             </span>
                                          </div>
                                       </div>
                                       <div class="invoice__righttbox">
                                          <span class="hirename">
                                             Fire's Name
                                          </span>
                                          <h5 class="name">
                                             Leslie Alexander
                                          </h5>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Age
                                             </span>
                                             <span class="counting">
                                                31
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Phone
                                             </span>
                                             <span class="counting">
                                                (684) 555-0102
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Email
                                             </span>
                                             <span class="counting">
                                                nvt.isst.nute@gmail.com
                                             </span>
                                          </div>
                                          <div class="invoice__leftnumber">
                                             <span class="bage">
                                                Addres
                                             </span>
                                             <span class="counting">
                                                Royal Ln. Mesa, New Jersey
                                             </span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Build the model
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Creta - MBW
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car category
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Enterprise
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Special
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Car on Self Drive
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent start Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent End Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   23-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Total Days
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car Regn. No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                6651 EY9F
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Out KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1012
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   In KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2123
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Ttal km(s)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   356
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of Payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Security deposit
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $7413
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Licence Issued
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Passport No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A4455444
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Id Issuing City
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Car Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Base Fare
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Taxes & Fee
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $99.00
                                             </span>
                                             <span>
                                                $13
                                             </span>
                                             <span>
                                                $114.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$4531.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Note : This is computer generated receipt and does not require physical signature.
                                    </p>
                                    <div class="print__point__btn d-flex align-items-center gap-3">
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                print
                                             </i>
                                          </span>
                                          <span class="print">
                                             Print
                                          </span>
                                       </a>
                                       <a href="print" class="cmn__btn">
                                          <span>
                                             <i class="material-symbols-outlined">
                                                download
                                             </i>
                                          </span>
                                          <span class="print">
                                             Download
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  --></code></pre>
                  </div>
               </div>
            </div>
            <!--home Car book-->
            <div class="common__body__section pb__60">
               <div class="common__body__head pb__20">
                  <h4>
                     Car Email
                  </h4>
                  <ul class="nav nav-pills" id="pills-tabblockshs4i" role="tablist">
                     <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tabhs4i" data-bs-toggle="pill" data-bs-target="#pills-homeblockshs4i" type="button" role="tab" aria-controls="pills-homeblockshs4i" aria-selected="true">
                           Preview
                        </button>
                     </li>
                     <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tabhs4i" data-bs-toggle="pill" data-bs-target="#pills-profileblcokshs4i" type="button" role="tab" aria-controls="pills-profileblcokshs4i" aria-selected="false">
                        Html Code
                        </button>
                     </li>
                  </ul>
               </div>
               <div class="tab-content" id="pills-tabContentrehs4i">
                  <div class="tab-pane fade show active" id="pills-homeblockshs4i" role="tabpanel" aria-labelledby="pills-home-tabhs4i">
                     <section class="order__section pt__60 pb__60">
                        <div class="container">
                           <div class="row">
                              <div class="col-xxl-8 col-xl-10 col-lg-12">
                                 <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                    <div class="invoice__textwrapper mb__10">
                                       <div class="invoice__leftbox">
                                          <h3 class="dtext xs-32">
                                             Rechargio
                                          </h3>
                                       </div>
                                       <div class="invoice__righttbox mt-2">
                                         <img src="assets/img/svg/pringting.svg" alt="img">
                                       </div>
                                    </div>
                                    <div class="reservation__contetn pb__30 mb__30">
                                       <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                          Hey Leslie Alexander,
                                       </span>
                                       <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                          <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                           <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                       </div>
                                       <p class="fz-16 fw-400 lato dtext">
                                          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                       </p>
                                    </div>
                                    <div class="invoice__journey mb__30">
                                       <h5 class="dtext border__bottom">
                                          Details
                                       </h5>
                                       <div class="d-flex journey__invoicedata">
                                          <ul class="jou__data">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Build the model
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Creta - MBW
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car category
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Delta Enterprise
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Special
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Car on Self Drive
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent start Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   22-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Rent End Date
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   23-12-23
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Total Days
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Car Regn. No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                  6651 EY9F
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Out KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   1012
                                                </span>
                                             </li>
                                          </ul>
                                          <ul class="jou__data jou__tadatwo">
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   In KM(S)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   2123
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Ttal km(s)
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   356
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Mode of Payment
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Credit Card
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Transaction
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   Success
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Security deposit
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   $7413
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Licence Issued
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                             <li class="d-flex border__bottom align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Passport No
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   A4455444
                                                </span>
                                             </li>
                                             <li class="d-flex align-items-center justify-content-between">
                                                <span class="fz-18 fw-400 lato dtext">
                                                   Id Issuing City
                                                </span>
                                                <span class="fz-18 fw-600 lato dtext">
                                                   New York
                                                </span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    <h5 class="dtext fw-700 passengertitle">
                                       Hirer's Name 
                                    </h5>
                                    <div class="getway__wrapper getway__wrapperbus">
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Name :
                                          </span>
                                          <span class="subtrans">
                                            Leslie Alexander
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Age :
                                          </span>
                                          <span class="subtrans">
                                             21
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Gender :
                                          </span>
                                          <span class="subtrans">
                                             Male
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Phone :
                                          </span>
                                          <span class="subtrans">
                                             (654) 555-0102
                                          </span>
                                       </div>
                                       <div class="getway__item">
                                          <span class="trnsdate fz-18 fw-400">
                                             Email :
                                          </span>
                                          <span class="subtrans">
                                             <a href="https://pixner.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="630d15174d091010174d0d16170623040e020a4d000c0e">[email&#160;protected]</a>
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__summary__wrapper mb__40">
                                       <div class="over__responsive">
                                       <h5 class="summary__title">Booking Summary</h5>
                                       <div class="order__table__fluid order__table__flight">
                                          <div class="order__table__items bg__add">
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Car Details
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Operrator
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Receive amount
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext d-block">
                                                Amount
                                             </span>
                                          </div>
                                          <div class="order__table__items bgaddtwo">
                                             <span>
                                                Delta 71613 - 
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                             <span>
                                                0
                                             </span>
                                             <span>
                                                $980.00
                                             </span>
                                          </div>
                                          <div class="order__table__itemsflight pb__15">
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Dubai To New York 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                Travel Date - Sun, 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                22 dec 22, 02:50 
                                             </span>
                                             <span class="fz-16 d-block fw-400 lato dtext">
                                                hrs
                                             </span>
                                          </div>
                                       </div>
                                       <div class="order__table__box bgaddtwo">
                                          <div class="order__graph">
                                             <ul>
                                                <li>
                                                   <span>Sub Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                                <li>
                                                   <span>Promotional Code:</span>
                                                   <span class="bg">0</span>
                                                </li>
                                                <li>
                                                   <span>Total:</span>
                                                   <span class="bg">$114.00</span>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       </div>
                                    </div>
                                    <p class="note">
                                       Any Questions? Get in touch with our 24x7 Customer Care team
                                    </p>
                                    <div class="print__point d-flex justify-content-center align-items-center">
                                       <a href="print.html" class="cmn__btn">
                                          <span class="print">
                                             Contact us
                                          </span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
                  <div class="tab-pane fade" id="pills-profileblcokshs4i" role="tabpanel" aria-labelledby="pills-profile-tabhs4i">
                     <pre><code class="language-markup"><!--
                    
                    <section class="order__section pt__60 pb__60">
                     <div class="container">
                        <div class="row justify-content-center">
                           <div class="col-xxl-8 col-xl-10 col-lg-12">
                              <div class="hotel__emailinvoice invoice__wrapper train__temail ">
                                 <div class="invoice__textwrapper mb__10">
                                    <div class="invoice__leftbox">
                                       <h3 class="dtext xs-32">
                                          Rechargio
                                       </h3>
                                    </div>
                                    <div class="invoice__righttbox mt-2">
                                    <img src="assets/img/svg/pringting.svg" alt="img">
                                    </div>
                                 </div>
                                 <div class="reservation__contetn pb__30 mb__30">
                                    <span class="dtext fz-16 fw-400 lato d-block mb__10">
                                       Hey Leslie Alexander,
                                    </span>
                                    <div class="input-esingl input-check d-flex align-items-center gap-2 payment__save mb__15">
                                       <img src="assets/img/svg/over-check.svg" class="overcheck" alt="img">
                                       <label for="saveForNextcard" class="gratext fz-18 fw-600 lato">Thank you! Your reservation has been confirmed.</label>
                                    </div>
                                    <p class="fz-16 fw-400 lato dtext">
                                       Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy...
                                    </p>
                                 </div>
                                 <div class="invoice__journey mb__30">
                                    <h5 class="dtext border__bottom">
                                       Details
                                    </h5>
                                    <div class="d-flex journey__invoicedata">
                                       <ul class="jou__data">
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Build the model
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Creta - MBW
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Car category
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Delta Enterprise
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Special
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Car on Self Drive
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Rent start Date
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                22-12-23
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Rent End Date
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                23-12-23
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Total Days
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                1
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Car Regn. No
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                             6651 EY9F
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Out KM(S)
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                1012
                                             </span>
                                          </li>
                                       </ul>
                                       <ul class="jou__data jou__tadatwo">
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                In KM(S)
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                2123
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Ttal km(s)
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                356
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Mode of Payment
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Credit Card
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Transaction
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                Success
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Security deposit
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                $7413
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Licence Issued
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                New York
                                             </span>
                                          </li>
                                          <li class="d-flex border__bottom align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Passport No
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                A4455444
                                             </span>
                                          </li>
                                          <li class="d-flex align-items-center justify-content-between">
                                             <span class="fz-18 fw-400 lato dtext">
                                                Id Issuing City
                                             </span>
                                             <span class="fz-18 fw-600 lato dtext">
                                                New York
                                             </span>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                                 <h5 class="dtext fw-700 passengertitle">
                                    Hirer's Name 
                                 </h5>
                                 <div class="getway__wrapper getway__wrapperbus">
                                    <div class="getway__item">
                                       <span class="trnsdate fz-18 fw-400">
                                          Name :
                                       </span>
                                       <span class="subtrans">
                                       Leslie Alexander
                                       </span>
                                    </div>
                                    <div class="getway__item">
                                       <span class="trnsdate fz-18 fw-400">
                                          Age :
                                       </span>
                                       <span class="subtrans">
                                          21
                                       </span>
                                    </div>
                                    <div class="getway__item">
                                       <span class="trnsdate fz-18 fw-400">
                                          Gender :
                                       </span>
                                       <span class="subtrans">
                                          Male
                                       </span>
                                    </div>
                                    <div class="getway__item">
                                       <span class="trnsdate fz-18 fw-400">
                                          Phone :
                                       </span>
                                       <span class="subtrans">
                                          (654) 555-0102
                                       </span>
                                    </div>
                                    <div class="getway__item">
                                       <span class="trnsdate fz-18 fw-400">
                                          Email :
                                       </span>
                                       <span class="subtrans">
                                          nvt.jsst.nute@gmai.com
                                       </span>
                                    </div>
                                 </div>
                                 <div class="order__summary__wrapper mb__40">
                                    <div class="over__responsive">
                                    <h5 class="summary__title">Booking Summary</h5>
                                    <div class="order__table__fluid order__table__flight">
                                       <div class="order__table__items bg__add">
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Car Details
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Operrator
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Receive amount
                                          </span>
                                          <span class="fz-18 fw-600 lato dtext d-block">
                                             Amount
                                          </span>
                                       </div>
                                       <div class="order__table__items bgaddtwo">
                                          <span>
                                             Delta 71613 - 
                                          </span>
                                          <span>
                                             $980.00
                                          </span>
                                          <span>
                                             0
                                          </span>
                                          <span>
                                             $980.00
                                          </span>
                                       </div>
                                       <div class="order__table__itemsflight pb__15">
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             Dubai To New York 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             Travel Date - Sun, 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             22 dec 22, 02:50 
                                          </span>
                                          <span class="fz-16 d-block fw-400 lato dtext">
                                             hrs
                                          </span>
                                       </div>
                                    </div>
                                    <div class="order__table__box bgaddtwo">
                                       <div class="order__graph">
                                          <ul>
                                             <li>
                                                <span>Sub Total:</span>
                                                <span class="bg">$114.00</span>
                                             </li>
                                             <li>
                                                <span>Promotional Code:</span>
                                                <span class="bg">0</span>
                                             </li>
                                             <li>
                                                <span>Total:</span>
                                                <span class="bg">$114.00</span>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                    </div>
                                 </div>
                                 <p class="note">
                                    Any Questions? Get in touch with our 24x7 Customer Care team
                                 </p>
                                 <div class="print__point d-flex justify-content-center align-items-center">
                                    <a href="print" class="cmn__btn">
                                       <span class="print">
                                          Contact us
                                       </span>
                                    </a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  --></code></pre>
                  </div>
               </div>
            </div>



            @if (Session::has('company_id') && Session::has('financial_year'))
            <ul class="main-menu">
            <li class="grid__style">
              <a href="{{ route('companies.create') }}" class="d-flex">
                  <span>Create Company</span>
                   <span class="icons">
                      <i class="material-symbols-outlined">
                         expand_more
                      </i>
                   </span>
                </a>
             </li>
             <li class="grid__style">
              <a href="{{ route('companies.create') }}" class="d-flex">
                  <span>Edit Company</span>
                   <span class="icons">
                      <i class="material-symbols-outlined">
                         expand_more
                      </i>
                   </span>
                </a>
             </li>
          </ul>
         @endif


         front home
         <section class="banner__section__two">
   <div class="banner__wrapper__two">
      <div class="container mt-5">
         <div class="row g-4 justify-content-center">
            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-12 wow fadeInUp" data-wow-duration="1.5s">
               <div class="fasilities__wrapper pb__40">
               </div>
            </div>
            <div class="col-xxl-6 col-xl-6 col-lg-8 col-md-8">
            <div class="card p-4 shadow-sm">
                <div class="card-header text-center text-white">
                    <h5 class="mb-0">Select Company & Financial Year</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('company.select') }}" method="POST">
                        @csrf
                        <div class="row g-3">
                            <div class="col-lg-6">
                                <div class="form-floating">
                                    <select name="company" id="company" class="form-select @error('company') is-invalid @enderror">
                                        <option value="">-- Choose Company --</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->id }}">{{ $company->name }}</option>
                                        @endforeach
                                    </select>
                                    <label for="company">Select Company</label>
                                    @error('company')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-floating">
                                    <select name="financial_year" id="financial_year" class="form-select @error('financial_year') is-invalid @enderror">
                                        <option value="">-- Choose Financial Year --</option>
                                        @foreach($financial_years as $year)
                                            <option value="{{ $year->id }}">{{ $year->year }}</option>
                                        @endforeach
                                    </select>
                                    <label for="financial_year">Select Financial Year</label>
                                    @error('financial_year')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="cmn__btn mt-5 w-100 py-2 mt-3">
                                      <span>
                           Continue
                        </span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
               <!-- <h4 class="promo__title mb__30">
                  Promo Code
               </h4>
               <div class="promo__sponsor__wrappertwo owl-theme owl-carousel">
                  <div class="promo__sponsor__item">
                     <div class="promo__box">
                        <div class="thumb">
                           <img src="assets/img/payment/aritel.png" alt="img">
                        </div>
                        <div class="content">
                           <span class="fz-16 link">
                              SWyro5ruq2Eu
                           </span>
                           <a href="order.html">
                              <span>
                                 Apply
                              </span>
                              <span class="icon">
                                 <i class="material-symbols-outlined">
                                    east
                                 </i>
                              </span>
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="promo__sponsor__item">
                     <div class="promo__box">
                        <div class="thumb">
                           <img src="assets/img/payment/paypal.png" alt="img">
                        </div>
                        <div class="content">
                           <span class="fz-16 link">
                              OayKsH7Xmr0O
                           </span>
                           <a href="order.html">
                              <span>
                                 Apply
                              </span>
                              <span class="icon">
                                 <i class="material-symbols-outlined">
                                    east
                                 </i>
                              </span>
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="promo__sponsor__item">
                     <div class="promo__box">
                        <div class="thumb">
                           <img src="assets/img/payment/aritel.png" alt="img">
                        </div>
                        <div class="content">
                           <span class="fz-16 link">
                              SWyro5ruq2Eu
                           </span>
                           <a href="order.html">
                              <span>
                                 Apply
                              </span>
                              <span class="icon">
                                 <i class="material-symbols-outlined">
                                    east
                                 </i>
                              </span>
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="promo__sponsor__item">
                     <div class="promo__box">
                        <div class="thumb">
                           <img src="assets/img/payment/paypal.png" alt="img">
                        </div>
                        <div class="content">
                           <span class="fz-16 link">
                              OayKsH7Xmr0O
                           </span>
                           <a href="order.html">
                              <span>
                                 Apply
                              </span>
                              <span class="icon">
                                 <i class="material-symbols-outlined">
                                    east
                                 </i>
                              </span>
                           </a>
                        </div>
                     </div>
                  </div>
               </div> -->
            </div>
           
            <!-- <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6">
               <div class="pay__sponsor__thumbtwo">
                  <img src="assets/img/banner/mobile2.jpg" alt="img">
               </div>
            </div> -->
         </div>
      </div>
   </div>
</section>