<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoodsStock extends Model
{
    use HasFactory;

    protected $table = 'goods_stock';

    protected $fillable = [
        'inward_challan_items_id',
        'item_name',
        'kgs',
        'pcs',
        'remaining_qty',
        'status',
    ];

    /**
     * Relationship: GoodsStock belongs to InwardChallanItem
     */
    public function inwardChallanItem()
    {
        return $this->belongsTo(InwardChallanItem::class, 'inward_challan_items_id');
    }
}
